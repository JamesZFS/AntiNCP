const bs = require('binarysearch');
console.log(bs.closest([1, 2, 4, 72, 218412], 0));
