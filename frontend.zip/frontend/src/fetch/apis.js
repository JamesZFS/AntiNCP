export const GET_EPIDEMIC_DATA = '/api/retrieve/epidemic';
export const COMMUNICATION_TEST = '/api/retrieve/test';
